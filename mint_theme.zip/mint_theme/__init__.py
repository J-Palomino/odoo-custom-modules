# -*- coding: utf-8 -*-
# Mint Green Theme - No Python code needed, just CSS overrides
